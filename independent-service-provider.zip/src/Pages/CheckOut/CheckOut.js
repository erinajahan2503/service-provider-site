import React from 'react';

const CheckOut = () => {
    return (
        <div>
            <h3>This is checkout</h3>
        </div>
    );
};

export default CheckOut;