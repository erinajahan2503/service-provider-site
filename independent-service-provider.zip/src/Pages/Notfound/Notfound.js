import React from 'react';
import notfound from '../../images/logo/notfound.jpg'
const Notfound = () => {
    return (
        <div>
            <img src={notfound} alt="" srcset="" />

        </div>
    );
};

export default Notfound;